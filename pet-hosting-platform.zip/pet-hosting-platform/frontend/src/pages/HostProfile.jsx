import { useEffect, useState } from 'react'
import api from '../lib/axios'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext' // ✅ importamos el contexto

export default function HostProfile() {
  const [host, setHost] = useState({
    name: '',
    type: 'particular',
    location: '',
    description: '',
  })

  const [tamanos, setTamanos] = useState([])
  const [especies, setEspecies] = useState([])
  const [servicios, setServicios] = useState([])

  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  const { user } = useAuth() // ✅ obtenemos el usuario actual

  // Cargar datos existentes
  useEffect(() => {
    api.get('/hosts')
      .then(res => {
        if (res.data.length > 0) {
          setHost(res.data[0])
        }
      })

    api.get('/user')
      .then(res => {
        setTamanos(res.data.tamanos_aceptados || [])
        setEspecies(res.data.especie_preferida || [])
        setServicios(res.data.servicios_ofrecidos || [])
      })
      .catch(() => setError('Error al cargar tus datos'))
  }, [])

  // Guardar perfil completo
  const handleSubmit = async e => {
    e.preventDefault()
    setError('')
    setSuccess('')

    try {
      if (host.id) {
        await api.put(`/hosts/${host.id}`, host)
      } else {
        await api.post('/hosts', host)
      }

      await api.put('/user', {
        tamanos_aceptados: tamanos,
        especie_preferida: especies,
        servicios_ofrecidos: servicios,
      })

      setSuccess('Perfil actualizado correctamente ✅')
    } catch (err) {
      console.error(err)
      setError('Error al guardar los datos')
    }
  }

  // Utilidad para checkboxes
  const toggleArrayValue = (array, value) =>
    array.includes(value)
      ? array.filter(item => item !== value)
      : [...array, value]

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">
        {user?.role === 'empresa' ? 'Perfil de Empresa' : 'Perfil de Cuidador'}
      </h1>

      {success && <p className="text-green-600 mb-2">{success}</p>}
      {error && <p className="text-red-600 mb-2">{error}</p>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Nombre del perfil"
          value={host.name}
          onChange={e => setHost({ ...host, name: e.target.value })}
          className="w-full border rounded px-3 py-2"
        />

        <select
          value={host.type}
          onChange={e => setHost({ ...host, type: e.target.value })}
          className="w-full border rounded px-3 py-2"
        >
          <option value="particular">Particular</option>
          <option value="empresa">Empresa</option>
        </select>

        <input
          type="text"
          placeholder="Ubicación"
          value={host.location}
          onChange={e => setHost({ ...host, location: e.target.value })}
          className="w-full border rounded px-3 py-2"
        />

        <textarea
          placeholder="Descripción"
          value={host.description}
          onChange={e => setHost({ ...host, description: e.target.value })}
          className="w-full border rounded px-3 py-2"
        />

        <div>
          <h2 className="font-semibold mb-2">¿Qué tipo de mascota aceptas?</h2>
          {['perro', 'gato'].map(especie => (
            <label key={especie} className="block">
              <input
                type="checkbox"
                checked={especies.includes(especie)}
                onChange={() =>
                  setEspecies(prev => toggleArrayValue(prev, especie))
                }
              />{' '}
              {especie.charAt(0).toUpperCase() + especie.slice(1)}
            </label>
          ))}
        </div>

        <div>
          <h2 className="font-semibold mb-2">¿Qué tamaños aceptas?</h2>
          {['pequeño', 'mediano', 'grande', 'gigante'].map(t => (
            <label key={t} className="block">
              <input
                type="checkbox"
                checked={tamanos.includes(t)}
                onChange={() =>
                  setTamanos(prev => toggleArrayValue(prev, t))
                }
              />{' '}
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </label>
          ))}
        </div>

        <div>
          <h2 className="font-semibold mb-2">¿Qué servicios ofreces?</h2>
          {['paseo', 'alojamiento', 'guarderia', 'cuidado a domicilio', 'visitas a domicilio'].map(servicio => (
            <label key={servicio} className="block">
              <input
                type="checkbox"
                checked={servicios.includes(servicio)}
                onChange={() =>
                  setServicios(prev => toggleArrayValue(prev, servicio))
                }
              />{' '}
              {servicio.charAt(0).toUpperCase() + servicio.slice(1)}
            </label>
          ))}
        </div>

        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Actualizar perfil
        </button>
      </form>

      <Link to="/" className="block mt-6 text-sm text-blue-600 hover:underline">
        ← Volver a inicio
      </Link>
    </div>
  )
}
